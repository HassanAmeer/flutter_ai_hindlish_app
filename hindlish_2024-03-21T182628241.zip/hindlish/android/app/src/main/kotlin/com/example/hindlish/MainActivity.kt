package com.example.hindlish

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
